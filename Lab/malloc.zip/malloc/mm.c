/* 
 * 1900094619 金镇雄
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "mm.h"
#include "memlib.h"

/* do not change the following! */
#ifdef DRIVER
/* create aliases for driver tests */
#define malloc mm_malloc
#define free mm_free
#define realloc mm_realloc
#define calloc mm_calloc
#endif /* def DRIVER */

/* single word (4) or double word (8) alignment */
#define ALIGNMENT 8

/* rounds up to the nearest multiple of ALIGNMENT */
#define ALIGN(size) (((size) + (ALIGNMENT-1)) & ~0x7)
#define SIZE_T_SIZE (ALIGN(sizeof(size_t)))
#define SIZE_PTR(p)  ((size_t*)(((char*)(p)) - SIZE_T_SIZE))

/* Basic constants and macros */
#define WSIZE       4       /* Word and header/footer size (bytes) */ 
#define DSIZE       8       /* Double word size (bytes) */
#define CHUNKSIZE  (1<<14)  /* Extend heap by this amount (bytes) */  

#define MAX(x, y) ((x) > (y) ? (x) : (y))

/* Pack a size and allocated bit into a word */
#define PACK(size, alloc)  ((size) | (alloc))

/* Read and write a word at address p */
#define GET(p)       (*(int *)(p))
#define PUT(p, val)  (*(int *)(p) = (val))

/* Read the size and allocated fields from address p */
#define GET_SIZE(p)  (GET(p) & ~0x7)
#define GET_ALLOC(p) (GET(p) & 0x1)

/* Given block ptr bp, compute address of its header and footer */
#define HDRP(bp)       ((void *)(bp) - WSIZE)
#define FTRP(bp)       ((void *)(bp) + GET_SIZE(HDRP(bp)) - DSIZE)

/* Given block ptr bp, compute address of next and previous blocks */
#define NEXT_BLKP(bp)  ((void *)(bp) + GET_SIZE(HDRP(bp)))
#define PREV_BLKP(bp)  ((void *)(bp) - GET_SIZE(HDRP(bp) - WSIZE))

/* Given block ptr bp, compute address of next and previous free blocks */
#define NEXT_FBLK(bp)(*(void **)(bp + DSIZE))
#define PREV_FBLK(bp)(*(void **)(bp))

/* Global variables */
static char *heap_listp = 0; /* Pointer to the first block */
static char *fblk_listp = 0; /* Pointer to the first free block */

/* Function prototypes for internal helper routines */
static void *extend_heap(size_t words);
static void place(void *bp, size_t asize);
static void *find_fit(size_t asize);
static void *coalesce(void *bp);
static void remove_FreeBlock(void *bp); /* Linked list function */

/* 
 * mm_init - Initialize the memory manager 
 */
int mm_init(void) {
	if ((heap_listp = mem_sbrk(6*DSIZE)) == NULL) return -1;
	PUT(heap_listp, 0);
	PUT(heap_listp + WSIZE, PACK(3*DSIZE, 1));
	PUT(heap_listp + DSIZE, 0); 
	PUT(heap_listp + DSIZE + WSIZE, 0); 
	PUT(heap_listp + 3*DSIZE, PACK(3*DSIZE, 1)); 
	PUT(heap_listp + 7*WSIZE, PACK(0, 1)); 
	fblk_listp = heap_listp + DSIZE; 
	if (extend_heap(CHUNKSIZE/WSIZE) == NULL) return -1;
	return 0;
}

/*
 * malloc - Allocate a block with at least size bytes of payload 
 */
void *malloc(size_t size) {
    size_t asize; 
    size_t extendsize;
    char *bp;

    if (!size) return NULL;
    if (heap_listp == 0) mm_init();

    if (ALIGN(size) > 2*DSIZE) asize = ALIGN(size) + DSIZE;
    else asize = 3*DSIZE;

    if ((bp = find_fit(asize))) {
	place(bp, asize);
	return bp;
    }

    extendsize = MAX(asize, CHUNKSIZE);
    if ((bp = extend_heap(extendsize/WSIZE)) == NULL) return NULL;
    place(bp, asize);
    return bp;
} 

/* 
 * free - Free a block 
 */
void free(void *bp)
{
    if(!bp) return; 
    size_t size = GET_SIZE(HDRP(bp));
    PUT(HDRP(bp), PACK(size, 0)); 
    PUT(FTRP(bp), PACK(size, 0));
    coalesce(bp);
}

/*
 * mm_realloc - Reallocate a block
 * This function extends or shrinks an allocated block.
 * If the new size is <= 0, then just free the block.
 * If the new size is the same as the old size,just return the old ptr.
 * If the new size is less than the old size, shrink the block
 * by changing the size in the header and footer of the block.
 * Then, if the remaining is at least teh 3*DSIZE block size, create a free 
 * block.
 * If the new size is greater than the old size, call malloc using the new size,
 * copy all of the old data, then call free to the original block.
 *
 * This function takes a block pointer and a new size as parameters and 
 * returns a block pointer to the newly allocated block.
 */
void *realloc(void *oldptr, size_t size) {
    size_t oldsize;
    void *newptr;
    size_t asize;
    if(!size) { // if (size == 0) realloc = free
	free(oldptr);
	return 0;
    }
    if(!oldptr) return malloc(size); // if (oldptr == NULL) realloc = malloc
    oldsize = GET_SIZE(HDRP(oldptr));	
    asize = MAX(ALIGN(size) + DSIZE, 3*DSIZE);
    // if alligned size is equall to old size than return oldptr
    if (asize == oldsize) return oldptr;
    // if alligned size is smaller than oldsize
    else if(asize < oldsize) {
	if(oldsize - asize > 3*DSIZE){
	    PUT(HDRP(oldptr), PACK(asize, 1));
	    PUT(FTRP(oldptr), PACK(asize, 1));
	    PUT(HDRP(NEXT_BLKP(oldptr)), PACK(oldsize-asize, 1));
	    free(NEXT_BLKP(oldptr));
	}
	return oldptr;
    }
    // if alligned size is bigger than old size than ask for a new block
    newptr = malloc(size);
    if(!newptr) return 0;
    /* Copy the old data. */
    if(size < oldsize) oldsize = size;
    memcpy(newptr, oldptr, oldsize);

    /* Free the old block. */
    mm_free(oldptr);
    return newptr;
}

/*
 * calloc 
 * malloc and fill the block with zero
*/
void *calloc (size_t nmemb, size_t size) {
    size_t s = nmemb * size;
    void *ptr;
    ptr = malloc(s);
    memset(ptr, 0, s);
    return ptr;
}

/* 
 * mm_checkheap - Check the heap for correctness.
 */
void mm_checkheap(int v) {
    void *bp = fblk_listp;
    if (v) printf("Heap (%p):\n", heap_listp);
    if ((GET_SIZE(HDRP(heap_listp)) != DSIZE) || !GET_ALLOC(HDRP(heap_listp)))
	printf("Error: Start Header\n");

    while(GET_ALLOC(HDRP(bp)) == 0){
	if (v) {
   		char a,b;
    		if(GET_ALLOC(HDRP(bp))) a = 'a';
    		else a = 'f';
    		if(GET_ALLOC(FTRP(bp))) b = 'a';
    		else b = 'f';
    		printf("%p: header: <%d:%c> footer: <%d:%c>\n", bp, GET_SIZE(HDRP(bp))
		, a, GET_SIZE(FTRP(bp)), b);
	}
	if ((size_t)bp % 8)
	printf("Error [%p]: Not Doubleword aligned\n", bp);
    	if (GET(HDRP(bp)) != GET(FTRP(bp)))
	printf("Error [%p]: Header != Footer \n");
        bp = NEXT_FBLK(bp);
    }

    if ((GET_SIZE(HDRP(bp)) != 0) || !(GET_ALLOC(HDRP(bp))))
	printf("Error: End Header\n");
    return;
}


/* 
 * The remaining routines are internal helper routines 
 */


/* 
 * extend_heap - Extend heap with free block and return its block pointer
 */
static void *extend_heap(size_t words) {
    char *bp;
    size_t size;

    /* Allocate an even number of words to maintain alignment */
    size = (words % 2) ? (words+1) * WSIZE : words * WSIZE;
    if (size < 3*DSIZE)
	size = 3*DSIZE;
    if ((long)(bp = mem_sbrk(size)) == -1) 
	return NULL;

    /* Initialize free block header/footer and the epilogue header */
    PUT(HDRP(bp), PACK(size, 0));         /* Free block header */
    PUT(FTRP(bp), PACK(size, 0));         /* Free block footer */
    PUT(HDRP(NEXT_BLKP(bp)), PACK(0, 1)); /* New epilogue header */

    /* Coalesce if the previous block was free */ 
    return coalesce(bp);
}

/* 
 * place - Place block of asize bytes at start of free block bp 
 */
static void place(void *bp, size_t asize)
{
    size_t csize = GET_SIZE(HDRP(bp)) - asize;
    if (csize >= 3*DSIZE) {
	PUT(HDRP(bp), PACK(asize, 1));
	PUT(FTRP(bp), PACK(asize, 1));
	remove_FreeBlock(bp);
	bp = NEXT_BLKP(bp);
	PUT(HDRP(bp), PACK(csize, 0));
	PUT(FTRP(bp), PACK(csize, 0));
	coalesce(bp);
    }
    else {
	PUT(HDRP(bp), PACK(csize + asize, 1));
	PUT(FTRP(bp), PACK(csize + asize, 1));
	remove_FreeBlock(bp);
    }
}

/* 
 * find_fit - Find a fit for a block with asize bytes 
 */
static void *find_fit(size_t asize)
{
	
    void *bp = fblk_listp;
    /* Best fit - Util 42, Thru 0 */ 
/*
    void *tmp = NULL;
    size_t min = 0, size;
    for(bp = fblk_listp; GET_ALLOC(HDRP(bp)) == 0; bp = NEXT_FBLK(bp)){
	size = GET_SIZE(HDRP(bp));
        if((size >= asize) &&  (!min || min > size)){
            min = size;
            tmp = bp;
	}
    }
    return tmp; 
}
*/

    /* First fit */
    while(GET_ALLOC(HDRP(bp)) == 0){
	if (asize <= GET_SIZE(HDRP(bp)))
	    return bp;
	bp = NEXT_FBLK(bp);
    }
    return NULL;
}

/*
 * coalesce - boundary tag coalescing. 
 * This function joins adjecent free blocks together by 
 * finding the size (newsize) of the new (bigger) free block, removing the
 * free block(s) from the free list, and changing the header
 * and footer information to the newly coalesced free block
 * (size = newsize, allocated = 0)
 * Then, we add the new free block to the front of the free list.
 * 
 * This function takes a block pointer to the newly freed block (around which
 * we must coalesce) and returns the block pointer to the coalesced free
 * block.
 * Return ptr to coalesced block
*/
static void *coalesce(void *bp) {
    size_t prev_alloc = GET_ALLOC(FTRP(PREV_BLKP(bp))) || PREV_BLKP(bp) == bp;
    size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(bp)));
    size_t size = GET_SIZE(HDRP(bp));
	/* | -- | bp |    |  ==> | -- |    bp    | */
    if (prev_alloc && !next_alloc) {			
	size += GET_SIZE(HDRP(NEXT_BLKP(bp)));
	remove_FreeBlock(NEXT_BLKP(bp));
	PUT(HDRP(bp), PACK(size, 0));
	PUT(FTRP(bp), PACK(size, 0));
    }
	/* |    | bp | -- |  ==> |    bp    | -- | */
    else if (!prev_alloc && next_alloc) {		
	size += GET_SIZE(HDRP(PREV_BLKP(bp)));
	bp = PREV_BLKP(bp);
	remove_FreeBlock(bp);
	PUT(HDRP(bp), PACK(size, 0));
	PUT(FTRP(bp), PACK(size, 0));
    }
	/* |    | bp |    |  ==> |       bp      |*/
    else if (!prev_alloc && !next_alloc) {		
	size += GET_SIZE(HDRP(PREV_BLKP(bp))) +	GET_SIZE(HDRP(NEXT_BLKP(bp)));
	remove_FreeBlock(PREV_BLKP(bp));
	remove_FreeBlock(NEXT_BLKP(bp));
	bp = PREV_BLKP(bp);
	PUT(HDRP(bp), PACK(size, 0));
	PUT(FTRP(bp), PACK(size, 0));
    }	

    NEXT_FBLK(bp) = fblk_listp; //Sets next ptr to start of free list
    PREV_FBLK(fblk_listp) = bp; //Sets current's prev to new block
    PREV_FBLK(bp) = NULL; // Sets prev pointer to NULL
    fblk_listp = bp; // Sets start of free list as new block

    return bp;
}

/*
 * remove_FreeBlock - Removes the block from the free list of bp
 */
static void remove_FreeBlock(void *bp) {
    if (PREV_FBLK(bp)) NEXT_FBLK(PREV_FBLK(bp)) = NEXT_FBLK(bp);
    else fblk_listp = NEXT_FBLK(bp); 
    PREV_FBLK(NEXT_FBLK(bp)) = PREV_FBLK(bp);
}

