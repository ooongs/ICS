/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_477(unsigned *p)
{
    *p = 2496104776U;
}

unsigned addval_347(unsigned x)
{
    return x + 3281031256U;
}

unsigned getval_229()
{
    return 2425379056U;
}

unsigned addval_309(unsigned x)
{
    return x + 2445773128U;
}

void setval_332(unsigned *p)
{
    *p = 3281031768U;
}

unsigned getval_133()
{
    return 2425393496U;
}

unsigned getval_180()
{
    return 2428995912U;
}

void setval_157(unsigned *p)
{
    *p = 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_117(unsigned x)
{
    return x + 3281044121U;
}

unsigned addval_257(unsigned x)
{
    return x + 3285059914U;
}

unsigned addval_408(unsigned x)
{
    return x + 633586313U;
}

void setval_396(unsigned *p)
{
    *p = 3682913931U;
}

unsigned addval_266(unsigned x)
{
    return x + 3767093423U;
}

unsigned addval_431(unsigned x)
{
    return x + 2143800969U;
}

unsigned addval_265(unsigned x)
{
    return x + 3374891657U;
}

unsigned addval_490(unsigned x)
{
    return x + 3374895497U;
}

unsigned getval_140()
{
    return 2497743176U;
}

unsigned addval_233(unsigned x)
{
    return x + 3222851209U;
}

void setval_460(unsigned *p)
{
    *p = 3380920969U;
}

void setval_131(unsigned *p)
{
    *p = 3375943945U;
}

unsigned getval_357()
{
    return 3224948360U;
}

unsigned getval_182()
{
    return 3223375513U;
}

unsigned getval_132()
{
    return 3531919785U;
}

unsigned getval_378()
{
    return 3523793289U;
}

void setval_488(unsigned *p)
{
    *p = 2464188744U;
}

unsigned addval_400(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_184()
{
    return 3285092719U;
}

unsigned addval_350(unsigned x)
{
    return x + 2495777222U;
}

unsigned getval_423()
{
    return 3680551561U;
}

void setval_413(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_297(unsigned x)
{
    return x + 3269495112U;
}

void setval_139(unsigned *p)
{
    *p = 3221803401U;
}

unsigned addval_427(unsigned x)
{
    return x + 3286272840U;
}

unsigned addval_479(unsigned x)
{
    return x + 3223372427U;
}

unsigned addval_412(unsigned x)
{
    return x + 3682914696U;
}

unsigned getval_303()
{
    return 3286272264U;
}

unsigned addval_217(unsigned x)
{
    return x + 2764165513U;
}

void setval_360(unsigned *p)
{
    *p = 3267529079U;
}

unsigned getval_364()
{
    return 3532968329U;
}

void setval_264(unsigned *p)
{
    *p = 2425409161U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
