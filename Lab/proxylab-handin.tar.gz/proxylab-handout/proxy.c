#include <stdio.h>
#include "csapp.h"

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400
#define N 10

/* You won't lose style points for including this long line in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";
static const char *Connection_header = "Connection: close\r\n";
static const char *Proxy_Connection_header = "Proxy-Connection: close\r\n";    

void *thread(void *vargp);
void doit(int fd);
void parse_uri(char *uri,char *hostname,char *path,int *port);
void read_requesthdrs(rio_t *rp, char *request);
int reader(char *uri, int fd);
void writer(char *uri, char *buf);
int readcnt = 0;
sem_t mutex, w; // variable for reader and writer

typedef struct {
    char *object;
    char *i;
} Cache_base;

typedef struct {
    Cache_base* objects;
    int cnt;
} Cache;

Cache cache;


int main(int argc, char **argv)
{

    signal(SIGPIPE, SIG_IGN);

    int listenfd, *connfd;
    pthread_t tid;
    char hostname[MAXLINE], port[MAXLINE];
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;

    /* Check command line args */
    if (argc != 2) {
	fprintf(stderr, "usage: %s <port>\n", argv[0]);
	exit(1);
    }
    // init mutex and w for reader and writer
    Sem_init(&mutex, 0, 1);
    Sem_init(&w, 0, 1);
    readcnt = 0;

    // malloc cache
    cache.objects = (Cache_base*)Malloc(sizeof(Cache_base) * N);
    cache.cnt = 0;

    for (int i = 0; i < N; ++i) {
        cache.objects[i].i = Malloc(sizeof(char) * MAXLINE);
        cache.objects[i].object = Malloc(sizeof(char) * MAX_OBJECT_SIZE);
    }

    listenfd = Open_listenfd(argv[1]);
    while (1) {
	clientlen = sizeof(clientaddr);
        connfd = Malloc(sizeof(int));
	*connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
        Getnameinfo((SA *) &clientaddr, clientlen, hostname, MAXLINE, 
                    port, MAXLINE, 0);
        printf("Accepted connection from (%s, %s)\n", hostname, port);
        Pthread_create(&tid, NULL, thread, connfd);  
    }
    //free_cache(); never reach
    Close(listenfd);
    return 0;
}

void *thread(void *vargp)
{
    int connfd = *((int *)vargp);
    Pthread_detach(pthread_self());
    Free(vargp);
    doit(connfd);                                             
    Close(connfd);  
    return NULL;
}

void doit(int client_fd) 
{
    char buf[MAXLINE], method[MAXLINE], uri[MAXLINE], version[MAXLINE];
    char hostname[MAXLINE],path[MAXLINE];
    char port_Arr[N]; 
    char request[MAXLINE]; // request (send to server)

    int server_fd, port; 
    rio_t client, server;

    Rio_readinitb(&client, client_fd);
    if (!Rio_readlineb(&client, buf, MAXLINE)) return;

    // GET http://www.cmu.edu/hub/index.html HTTP/1.1
    // method:  GET
    // uri:     http://www.cmu.edu/hub/index.html 
    // version: HTTP/1.1
    sscanf(buf, "%s %s %s", method, uri, version);    
   
    if(reader(uri, client_fd)) return; // cache read data

    // parsing uri
    parse_uri(uri, hostname, path, &port);
    

    sprintf(port_Arr, "%d", port);
    server_fd = Open_clientfd(hostname, port_Arr);
    Rio_readinitb(&server, server_fd);

    sprintf(request, "GET %s HTTP/1.0\r\n", path); 

    // read and ignore header
    read_requesthdrs(&client, request);

    // making request
    sprintf(request, "%sHost: %s\r\n", request, hostname);
    sprintf(request, "%s%s", request, user_agent_hdr);
    sprintf(request, "%s%s", request, Connection_header);
    sprintf(request, "%s%s", request, Proxy_Connection_header);
    sprintf(request, "%s\r\n", request);

    // send request to server
    Rio_writen(server_fd, request, strlen(request)); 
    
    int n, size = 0;
    char data[MAX_OBJECT_SIZE];
    while ((n = Rio_readlineb(&server, buf, MAXLINE))) {
        if (size < MAX_OBJECT_SIZE) {
            memcpy(data + size, buf, n);
            size += n;
        }
        Rio_writen(client_fd, buf, n);  // server response to client
    }

    if(size < MAX_OBJECT_SIZE)
        writer(uri,data);

    Close(server_fd);
}

void parse_uri(char *uri,char *hostname,char *path,int *port) {
    if (strstr(uri, "http://") != uri) {
        fprintf(stderr, "Error: invalid uri!\n");
        exit(0);
    }
    // uri:     http://www.cmu.edu/hub/index.html 
    char* ptr1;
    char* ptr2;
    if (!(ptr1 = strstr(uri,"http://"))) ptr1 = uri;
    else ptr1 += 7;
    *port = 0;
    if (!(ptr2 = strstr(ptr1,":"))) { 
    	// if there is no port e.g) http://www.cmu.edu/hub/index.html 
        if (ptr2 = strstr(ptr1,"/")) { // find first "/" from "www.cmu.edu/hub/index.html"
   	    *ptr2 = '\0';
            strncpy(hostname, ptr1, MAXLINE); // 
            *ptr2 = '/';
	    return;
        }
        strncpy(path,ptr2,MAXLINE);            
	strncpy(hostname, ptr1, MAXLINE);
        strcpy(path,"");
	return;
    } 
    else {
	// if there is port e.g) http://www.google.com:80/index.html
        *ptr2 = '\0';
        strncpy(hostname, ptr1, MAXLINE); // hostname: www.google.com
        sscanf(ptr2 + 1, "%d%s", port, path); // port: 80     path: /index.html
        *ptr2 = ':';
	return;
    }
}

void read_requesthdrs(rio_t *rp, char *request) {
    char buf[MAXLINE];
    Rio_readlineb(rp, buf, MAXLINE);
    while(strcmp(buf, "\r\n")) {       
        Rio_readlineb(rp, buf, MAXLINE);
	sprintf(request,"%s: %s", request,buf);
    }
    return;
}


int reader(char *uri, int fd) {
    int flag = 0;
    P(&mutex);
    readcnt++;

    if (readcnt == 1)
        P(&w);
    V(&mutex);

    for (int i = 0; i < N; i++) {
        if (!strcmp(cache.objects[i].i, uri)) {
            Rio_writen(fd, cache.objects[i].object, MAX_OBJECT_SIZE);
            flag = 1;
            break;
        }
    }

    P(&mutex);
    readcnt--;
    if (readcnt == 0)
        V(&w);
    V(&mutex);

    return flag;
}

void writer(char *uri, char *buf) {
    P(&w);

    strcpy(cache.objects[cache.cnt].object, buf);
    strcpy(cache.objects[cache.cnt].i, uri);
    cache.cnt++;

    V(&w);
}
